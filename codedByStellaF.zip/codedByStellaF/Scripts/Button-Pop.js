// ——————————————————
// Scripts/Button-Pop.js
// ——————————————————

/* — Inject Pop Styles + Visual Rules — */
function injectPopStyles() {
  if (document.getElementById('pop-style')) return;
  const style = document.createElement('style');
  style.id = 'pop-style';
  style.textContent = `
    .menu-toggle {
      position: relative;
      overflow: hidden;
      z-index: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.6rem;
      margin: 1rem auto;
      font-family: 'Orbitron', sans-serif;
      font-size: 1.1rem;
      font-weight: bold;
      height: 40px;
      padding: 0 1.2rem;
      background: linear-gradient(to top, #ff4da6, #ff99cc);
      color: black;
      border: none;
      border-radius: 12px;
      outline: 2px solid #ff69b4;
      outline-offset: 2px;
      cursor: pointer;
      line-height: 40px;
      transform: translateY(-2px);
      transition: transform 0.2s ease, filter 0.2s ease;
      filter: url(#menuBottomShadow);
    }

    .menu-toggle.pressed {
      transform: translateY(2px);
    }

    .spin-wrapper {
      display: inline-block;
      margin-right: 0.5em;
      vertical-align: middle;
    }

    .menu-text {
      font-family: 'Orbitron', sans-serif;
      font-weight: 900;
      font-size: 1.3rem;
      letter-spacing: 1.2px;
      color: black;
      text-shadow:
        0 0 2px #fff,
        0 0 4px #fff,
        0 0 6px #ffb3ec,
        0 0 8px #ff66cc;
      transition: all 0.3s ease-in-out;
    }

    @keyframes popBack {
      0%   { transform: translateY(4px) scale(0.95); }
      100% { transform: translateY(0) scale(1); }
    }
  `;
  document.head.appendChild(style);
}

/* — Trigger Pop Animation — */
export function popMenuButton(btn) {
  injectPopStyles();
  document.getElementById('pop')?.play();
  btn.style.transition = 'transform 0.45s ease, filter 0.45s ease';
  btn.style.animation = 'popBack 0.45s ease-out forwards';
  btn.style.filter = 'url(#menuBottomShadow)';
  setTimeout(() => btn.style.removeProperty('animation'), 450);
}

/* — Touch Feedback Only — */
export function initPopButton() {
  injectPopStyles();
  const btn = document.getElementById('menu-toggle');
  if (!btn) return;

  btn.addEventListener('touchstart', () => btn.classList.add('pressed'));
  btn.addEventListener('touchend', () => {
    setTimeout(() => btn.classList.remove('pressed'), 150);
  });
}