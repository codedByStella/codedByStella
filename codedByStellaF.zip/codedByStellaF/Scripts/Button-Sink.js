// ——————————————————
// Scripts/Button-Sink.js
// ——————————————————

/**
 * Injects sink-specific keyframes and style rules
 * Applies top shadow for pressed visual
 */
function injectSinkStyles() {
  if (document.getElementById('sink-style')) return;

  const style = document.createElement('style');
  style.id = 'sink-style';
  style.textContent = `
    @keyframes sink {
      0%   { transform: translateY(0) scale(1); }
      100% { transform: translateY(4px) scale(0.95); }
    }

    .menu-toggle.sinking {
      animation: sink 0.2s ease forwards;
      filter: url(#menuTopShadow);
    }
  `;
  document.head.appendChild(style);
}

/**
 * Executes the sink animation on a given button
 * @param {HTMLElement} btn - The menu toggle button
 * @param {number} durationMs - Duration in milliseconds
 */
export function sinkMenuButton(btn, durationMs = 200) {
  injectSinkStyles();
  document.getElementById('clunk')?.play();

  // Reset any previous animation
  btn.classList.remove('sinking');
  btn.style.animation = 'none';
  void btn.offsetWidth; // force reflow
  btn.classList.add('sinking');

  // Clean up visual-only transition artifacts
  btn.style.transition = `transform ${durationMs}ms ease, filter ${durationMs}ms ease`;

  // Full cleanup after animation ends
  setTimeout(() => {
    btn.classList.remove('sinking');
    btn.style.removeProperty('transition');
    btn.style.removeProperty('animation');
  }, durationMs);
}

/**
 * Initialization hook for Loader.js
 * Ensures sink styles are injected at startup
 */
export function initSinkButton() {
  injectSinkStyles();
}