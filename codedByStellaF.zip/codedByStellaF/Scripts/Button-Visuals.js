// ——————————————————
// Scripts/Button-Visuals.js (SVG Shadow Version – Cleaned, No Pop)
// ——————————————————

/* — Inject Button Styles — */
function injectMenuButtonStyles() {
  if (document.getElementById('menu-button-styles')) return;

  const style = document.createElement('style');
  style.id = 'menu-button-styles';
  style.textContent = `
    .menu-toggle {
      position: relative;
      overflow: hidden;
      z-index: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.6rem;
      margin: 1rem auto;
      font-family: 'Orbitron', sans-serif;
      font-size: 1.1rem;
      font-weight: bold;
      height: 40px;
      padding: 0 1.2rem;
      background: linear-gradient(to top, #ff4da6, #ff99cc);
      color: black;
      border: none;
      border-radius: 12px;
      outline: 2px solid #ff69b4;
      outline-offset: 2px;
      cursor: pointer;
      line-height: 40px;
      transform: translateY(-2px);
      transition: transform 0.2s ease, filter 0.2s ease;
      filter: url(#menuBottomShadow);
      -webkit-filter: url(#menuBottomShadow);
    }

    .menu-toggle.pressed {
      transform: translateY(2px);
    }

    .spin-wrapper {
      display: inline-block;
      margin-right: 0.5em;
      vertical-align: middle;
    }

    .menu-text {
      font-family: 'Orbitron', sans-serif;
      font-weight: 900;
      font-size: 1.3rem;
      letter-spacing: 1.2px;
      color: black;
      text-shadow:
        0 0 2px #fff,
        0 0 4px #fff,
        0 0 6px #ffb3ec,
        0 0 8px #ff66cc;
      transition: all 0.3s ease-in-out;
    }
  `;
  document.head.appendChild(style);
}

/* — Initialize Button Styles + Touch Feedback — */
export function initButtonVisuals() {
  injectMenuButtonStyles();

  const btn = document.getElementById('menu-toggle');
  if (!btn) return;

  // Force-apply SVG shadow (for safety, even though CSS already does it)
  btn.style.filter = 'url(#menuBottomShadow)';
  btn.style.webkitFilter = 'url(#menuBottomShadow)';

  // Touch interaction
  btn.addEventListener('touchstart', () => btn.classList.add('pressed'));
  btn.addEventListener('touchend', () => {
    setTimeout(() => btn.classList.remove('pressed'), 150);
  });
}