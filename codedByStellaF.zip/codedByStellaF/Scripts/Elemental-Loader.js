import { includeHTML } from './Loader.js';

import { injectLogoTextStyles, initLogoText } from './Elements/Logo-Text.js';
import { injectTaglineTextStyles, initTaglineText } from './Elements/Tagline-Text.js'; // ✅ ADD THIS

includeHTML('navbar-include', 'Universal.html')
  .then(() => {
    injectLogoTextStyles();
    initLogoText();

    injectTaglineTextStyles();  
    initTaglineText();          
  })
  .catch(err => {
    console.error('Header injection failed:', err);
  });