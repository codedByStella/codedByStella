import { reflectAndShadow } from '../Modules/Reflections.js';

export function initLogoText() {
  const logoTarget = document.querySelector('.site-logo .outlined-logo');
  if (logoTarget) reflectAndShadow(logoTarget);
}

export function injectLogoTextStyles() {
  const styleId = 'logo-text-styles';
  if (document.getElementById(styleId)) return;

  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    .site-logo {
      font-family: 'Orbitron', sans-serif;
      font-size: clamp(2.2rem, 8vw, 3.5rem);
      font-weight: 1000;
      text-transform: none;
      letter-spacing: 0.04em;
      display: block;
      margin: 0 auto;
      padding: 0;
      text-align: center;

      background: linear-gradient(90deg, #ffd0e5, #fff0f8, #ffd0e5);
      background-size: 300% auto;
      background-position: center;
      -webkit-background-clip: text;
      -webkit-text-fill-color: #ff4fbf;

      text-shadow:
        -2px -2px 0 #000,
         2px -2px 0 #000,
        -2px  2px 0 #000,
         2px  2px 0 #000,
         0 0 6px #ffd0e5,
         0 0 12px rgba(255, 208, 229, 0.5);

      transition: all 0.3s ease;
      line-height: 1.1;
    }

    @keyframes shimmer-text {
      0%   { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
		
		.site-logo::after {
  content: attr(data-text);
  display: block;
  transform: scaleY(-1);
  opacity: 0.3;
  filter: blur(1px);
  color: #ffd0e5;
  line-height: 1;
  margin-top: -0.1em;
  pointer-events: none;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
}

    .site-logo .outlined-logo > span > span:first-child {
  text-shadow: none !important; /* clean slate for JS injection */
}

  `;
  document.head.appendChild(style);
}