// Scripts/Elements/Tagline-Text.js

import { reflectAndShadow } from '../Modules/Reflections.js';

export function injectTaglineTextStyles() {
  const styleId = 'tagline-text-style';
  if (document.getElementById(styleId)) return;

  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    .site-tagline {
      font-family: 'Orbitron', sans-serif;
      font-size: clamp(1.05rem, 4vw, 1.2rem);
      font-weight: 850;
      letter-spacing: 1px;
      color: #ffd5e5;
      display: block;
      margin: -0.3rem auto 0.3rem auto;
      padding: 0;
      line-height: 1.1;
      white-space: nowrap;
      text-align: center;
      position: relative;
      left: 50%;
      transform: translateX(-50%);
      z-index: 5;
      text-shadow:
        1px 1px 1px rgba(0, 0, 0, 0.6),
        0 0 3px rgba(255, 160, 200, 0.5),
        0 0 5px rgba(255, 160, 200, 0.35),
        0 0 8px rgba(255, 192, 203, 0.3);
    }

    .site-tagline .outlined-logo > span > span:first-child {
      text-shadow: none !important;
    }
  `;
  document.head.appendChild(style);
}

export function initTaglineText() {
  const target = document.querySelector('.site-tagline .outlined-logo');
  if (target) reflectAndShadow(target);
}