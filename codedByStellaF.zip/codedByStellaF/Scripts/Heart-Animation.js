// Scripts/Heart-Animation.js

export function injectHeartAnimation() {
  // 0) Unclip the header and every descendant so nothing can hide our hearts
  const header = document.querySelector('.site-header');
  if (header) {
    header.style.overflow = 'visible';
    header.querySelectorAll('*').forEach(el => {
      el.style.overflow = 'visible';
    });
  }

  // 1) Grab all taglines and ensure they won’t clip the hearts
  const taglines = document.querySelectorAll('.site-tagline');
  if (!taglines.length) {
    console.warn('No .site-tagline elements found.');
    return;
  }
  taglines.forEach(tl => {
    tl.style.overflow = 'visible';
  });

  // 2) Purge old hearts and inject new ones
  taglines.forEach(tl => {
    // remove any existing
    tl.querySelectorAll('.heart-wrapper').forEach(el => el.remove());

    // heart factory
    const makeHeart = () => {
      const svgNS = 'http://www.w3.org/2000/svg';
      const wrap  = document.createElement('span');
      wrap.classList.add('heart-wrapper');

      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('viewBox', '0 0 32 29');
      svg.setAttribute('width', '1.5rem');
      svg.setAttribute('height', '1.375rem');
      svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      svg.classList.add('heart-svg');

      const base = document.createElementNS(svgNS, 'path');
      base.setAttribute('d',
        'M23.6,0c-3,0-5.6,2.1-7.6,5.2C14,2.1,11.4,0,8.4,0' +
        'C3.8,0,0,3.6,0,8.1c0,7.1,9.6,11.5,16,20.9' +
        'c6.4-9.4,16-13.8,16-20.9C32,3.6,28.2,0,23.6,0z'
      );
      base.setAttribute('fill', '#B266FF');
      base.classList.add('core-heart');
      svg.appendChild(base);

      // three ripples
      for (let i = 1; i <= 3; i++) {
        const ripple = document.createElementNS(svgNS, 'path');
        ripple.setAttribute('d', base.getAttribute('d'));
        ripple.classList.add('heart-ripple');
        ripple.style.setProperty('--i', i);
        svg.appendChild(ripple);
      }

      wrap.appendChild(svg);
      return wrap;
    };

    // inject before and after the tagline text
    tl.prepend(makeHeart());
    tl.append(makeHeart());
  });

  // 3) Inject our CSS rules once for overflow + heart animations
  if (!document.getElementById('heart-style')) {
    const style = document.createElement('style');
    style.id = 'heart-style';
    style.textContent = `
      /* ─ Allow hearts & ripples to escape every container ─ */
      header.site-header,
      header.site-header *,
      .site-tagline,
      .site-tagline *,
      .heart-wrapper {
        overflow: visible !important;
      }

      /* ─ Heart wrapper ─ */
      .heart-wrapper {
        display: inline-block;
        width: 1.5rem;
        height: 1.375rem;
        margin: 0 0.35rem;
        vertical-align: middle;
        overflow: visible;
      }

      /* ─ Base heart SVG ─ */
      .heart-svg {
        width: 100%;
        height: 100%;
        display: block;
      }
      .core-heart {
        transform-origin: center;
        animation: corePulse 2.6s ease-in-out infinite;
      }

      /* ─ Ripples ─ */
      .heart-ripple {
        fill: none;
        stroke: hsl(calc(var(--i) * 80), 100%, 72%);
        stroke-width: 1.5;
        transform-origin: center;
        opacity: 0;
        animation: ripplePulse 2.6s ease-in-out infinite;
        animation-delay: calc(var(--i) * 0.35s);
      }

      @keyframes corePulse {
        0%, 100% { transform: scale(1); }
        50%      { transform: scale(1.2); }
      }
      @keyframes ripplePulse {
        0%   { opacity: 0.6;  transform: scale(1); }
        70%  { opacity: 0;    transform: scale(1.8); }
        100% { opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  }
}