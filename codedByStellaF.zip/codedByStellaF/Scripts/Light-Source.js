// Scripts/Light-Source.js

export function injectHeaderLightSource() {
  if (document.getElementById('header-light-style')) return;

  const style = document.createElement('style');
  style.id = 'header-light-style';
  style.textContent = `
    .header-branding::after {
  content: "";
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  transform-origin: center top;
  will-change: transform, opacity;
  width: 250%;
  height: 300%;
  background: radial-gradient(
    ellipse at center top,
    rgba(255, 255, 255, 0.5) 0%,
    rgba(255, 255, 255, 0.35) 15%,
    rgba(255, 255, 255, 0.1) 20%,
    rgba(255, 255, 255, 0.05) 25%,
    transparent 30%
  );
  pointer-events: none;
  z-index: 0;
  animation: glowPulse 4s ease-in-out infinite;
}

@keyframes glowPulse {
  0% {
    transform: translateX(-50%) scale(1);
    opacity: 0.7;
  }
  50% {
    transform: translateX(-50%) scale(1.05);
    opacity: 1;
  }
  100% {
    transform: translateX(-50%) scale(1);
    opacity: 0.7;
  }
}
  `;
  document.head.appendChild(style);
}