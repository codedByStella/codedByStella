// Scripts/Loader.js

import { injectMenuSparkles, initSparkles }     from './Sparkles.js';
import { initNav }                               from './Nav-core.js';
import { initSinkButton }                        from './Button-Sink.js';
import { initPopButton }                         from './Button-Pop.js';
import { injectHeartAnimation }                  from './Heart-Animation.js';
import { injectHeaderLightSource }               from './Light-Source.js';

/**
 * Fetches Universal.html, injects the <head> template + <header>,
 * then re-runs all your effects exactly once.
 */
export async function includeHTML(id, file) {
  console.log(`[includeHTML] Starting fetch for: ${file}`);

  try {
    const res = await fetch(file, { cache: 'no-cache' });
    if (!res.ok) throw new Error(`Failed to fetch ${file}: ${res.status}`);
    console.log(`[includeHTML] Fetched ${file} successfully`);

    const text = await res.text();
    const tmp = document.createElement('div');
    tmp.innerHTML = text;
    console.log(`[includeHTML] Parsed HTML from ${file}`);

    const headTpl = tmp.querySelector('#universal-head-template');
    if (headTpl?.content) {
      document.head.appendChild(headTpl.content.cloneNode(true));
      console.log(`[includeHTML] Injected <head> template`);
    } else {
      console.warn(`[includeHTML] No #universal-head-template found`);
    }

    const headerEl = tmp.querySelector('header.site-header');
    const placeholder = document.getElementById(id);
    if (!headerEl) throw new Error(`No <header class="site-header"> found in ${file}`);
    if (!placeholder) throw new Error(`No element with id="${id}" found in DOM`);

    const headerClone = headerEl.cloneNode(true);
    placeholder.replaceWith(headerClone);
    console.log(`[includeHTML] Replaced #${id} with injected header`);

    injectMenuSparkles();
    initSparkles();

    requestAnimationFrame(() => {
      initSinkButton();
      initPopButton();
      initNav();
      injectHeartAnimation();
      injectHeaderLightSource();
      headerClone.classList.add('loaded');
    });

    console.log(`[includeHTML] Initialization complete`);
    return true;

  } catch (err) {
    console.error(`[includeHTML] Error:`, err.message || err);
  }
}