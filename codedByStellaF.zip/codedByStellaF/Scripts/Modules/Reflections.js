export function reflectAndShadow(target) {
  if (!target) return;

  const text = target.textContent.trim();
  target.textContent = ''; // Clear original content

  for (let char of text) {
    if (char === ' ') {
      target.appendChild(document.createTextNode(' '));
      continue;
    }

    const wrapper = document.createElement('span');
    wrapper.style.display = 'inline-flex';
    wrapper.style.flexDirection = 'column';
    wrapper.style.alignItems = 'center';
    wrapper.style.lineHeight = '1em';
    wrapper.style.margin = '0';
    wrapper.style.padding = '0';

    const original = document.createElement('span');
    original.textContent = char;
    original.style.display = 'block';
    original.style.lineHeight = '1em';

    const mirror = document.createElement('span');
    mirror.textContent = char;
    mirror.classList.add('mirror-letter');
    mirror.style.lineHeight = '1em';
    mirror.style.pointerEvents = 'none';
    mirror.style.marginBottom = '-0.1em';

    mirror.style.transform = ['y', 'g'].includes(char.toLowerCase())
      ? 'scaleY(-0.6)'
      : 'scaleY(-0.75)';
    mirror.style.opacity = '0.25';
    mirror.style.filter = 'blur(1px)';
    mirror.style.transition = 'opacity 0.3s ease-out';

    mirror.style.webkitMaskImage = 'linear-gradient(to top, black 0%, rgba(0,0,0,0.6) 60%, transparent 100%)';
    mirror.style.maskImage        = 'linear-gradient(to top, black 0%, rgba(0,0,0,0.6) 60%, transparent 100%)';
    mirror.style.webkitMaskSize   = '100% 100%';
    mirror.style.maskSize         = '100% 100%';
    mirror.style.webkitMaskRepeat = 'no-repeat';
    mirror.style.maskRepeat       = 'no-repeat';

    mirror.style.marginTop = ['y', 'g'].includes(char.toLowerCase())
      ? '0.05em'
      : '-0.2em';

    wrapper.appendChild(original);
    wrapper.appendChild(mirror);
    target.appendChild(wrapper);
  }

  // === Dynamic shadow logic (tethered + skewed) ===
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      const light = document.querySelector('.header-branding');
      if (!light) return;

      const lightRect = light.getBoundingClientRect();
      const lightCenterX = lightRect.left + lightRect.width / 2;
      const lightRange = lightRect.width / 2;

      const mirrors = target.querySelectorAll('.mirror-letter');

      mirrors.forEach((mirror) => {
        const parent = mirror.parentElement;
        const original = parent?.firstChild;
        if (!original) return;

        const rect = original.getBoundingClientRect();
        const letterCenterX = rect.left + rect.width / 2;

        const distance = letterCenterX - lightCenterX;
        const norm = Math.max(Math.min(distance / lightRange, 1), -1);

        const exaggeration = Math.sign(norm) * Math.pow(Math.abs(norm), 1.2);
        const dx = -exaggeration * 20; // Inverted direction
        const dy = 20;

        mirror.style.textShadow = `${dx.toFixed(2)}px ${dy}px 20px rgba(0, 0, 0, 0.85)`;
      });
    });
  });
}