// Scripts/Nav-Animations.js

export async function openNav(nav, items, delay = 100, trans = 200) {
  nav.classList.remove('closing');
  nav.classList.add('show');
  nav.style.overflow = 'hidden';
  nav.style.height = '0';
  items.forEach(li => li.style.display = 'none');

  let accH = 0;
  for (const li of items) {
    await new Promise(r => setTimeout(r, delay));
    li.style.display = 'block';
    accH += li.offsetHeight || 48;
    nav.style.height = `${accH}px`;
    void nav.offsetHeight;
    animateNavItem(li, trans, 'ease-out', { y: -20, fadeIn: true });
  }

  return new Promise(res => {
    setTimeout(() => {
      res();
    }, 0);
  });
}

export async function closeNav(nav, items, delay = 0, trans = 200, totalMs = 200) {
  const heights = items.map(li => li.offsetHeight || 48);
  let currH = heights.reduce((a, b) => a + b, 0);

  nav.classList.add('closing');
  nav.style.overflow = 'hidden';
  nav.style.height = `${currH}px`;
  nav.style.transition = `height ${(totalMs / 1000).toFixed(2)}s ease-in-out`;
  void nav.offsetHeight;

  for (let i = 0; i < items.length; i++) {
    const li = items[i];
    const isLast = i === items.length - 1;

    if (!isLast) await new Promise(r => setTimeout(r, delay));

    animateNavItem(li, trans, 'ease', { y: -20, fadeIn: false });
    await new Promise(r => setTimeout(r, trans));

    li.style.transition = `height ${trans / 1000}s ease, padding ${trans / 1000}s ease, margin ${trans / 1000}s ease`;
    li.style.height = '0';
    li.style.padding = '0';
    li.style.margin = '0';
    li.style.overflow = 'hidden';

    currH -= heights.shift();
    nav.style.height = `${currH}px`;

    if (!isLast) {
      await new Promise(r => setTimeout(r, 50));
    } else {
      // 💣 Final item — wipe it out early
      nav.classList.remove('show');
      nav.style.backgroundColor = 'transparent';
      nav.style.padding = '0';
    }
  }

  return new Promise(res => {
    nav.addEventListener('transitionend', function fn(e) {
      if (e.propertyName === 'height') {
        nav.removeEventListener('transitionend', fn);
        nav.classList.remove('closing');
        ['overflow', 'height', 'transition', 'backgroundColor', 'padding'].forEach(p => nav.style[p] = '');

        items.forEach(li => {
          li.style.display = 'none';
          ['height', 'padding', 'margin', 'transition', 'overflow'].forEach(p => li.style[p] = '');
          li.querySelectorAll('.spin-wrapper, .nav-text').forEach(el => {
            ['opacity', 'transform', 'transition', 'transitionDelay'].forEach(k => el.style[k] = '');
          });
        });

        res();
      }
    });
  });
}

export function animateNavItem(li, duration, easing, { y, fadeIn }) {
  const wrapper = li.querySelector('.spin-wrapper');
  const text    = li.querySelector('.nav-text');

  if (fadeIn) {
    if (wrapper) {
      wrapper.style.transition = 'none';
      wrapper.style.opacity    = '0';
      wrapper.style.transform  = `translateY(${y * 2}px) scale(0.7)`;
      void wrapper.offsetHeight;
      wrapper.style.transition = `opacity ${duration / 1000}s ${easing}, transform ${duration / 1000}s ${easing}`;
      wrapper.style.opacity    = '1';
      wrapper.style.transform  = 'translateY(0) scale(1)';
    }
    if (text) {
      text.style.transition   = 'none';
      text.style.opacity      = '0';
      text.style.transform    = `translateY(${y * 2}px)`;
      void text.offsetHeight;
      setTimeout(() => {
        text.style.transition = `opacity ${duration / 1000}s ${easing}, transform ${duration / 1000}s ${easing}`;
        text.style.opacity    = '1';
        text.style.transform  = 'translateY(0)';
      }, 50);
    }
  } else {
    [wrapper, text].forEach(el => {
      if (!el) return;
      el.style.transition = `opacity ${duration / 1000}s ${easing}, transform ${duration / 1000}s ${easing}`;
      el.style.opacity    = '0';
      el.style.transform  = `translateY(${y * 2}px) scale(0.7)`;
    });
  }
}