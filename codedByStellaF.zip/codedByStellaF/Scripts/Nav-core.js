// Scripts/Nav-Core.js

import { sinkMenuButton } from './Button-Sink.js';
import { popMenuButton } from './Button-Pop.js';
import { openNav, closeNav } from './Nav-Animations.js';

// ——————————————————
// Sink → Pop Trigger
// ——————————————————
export function sinkThenPop(btn) {
  const nav    = document.querySelector('.nav-links');
  const items  = Array.from(nav.querySelectorAll('li'));
  const isOpen = nav.classList.contains('show');

  // 1) sink immediately
  sinkMenuButton(btn, 200);

  // 2) toggle nav, then pop
  if (!isOpen) {
    openNav(nav, items, 100, 200).then(() => {
      btn.setAttribute('aria-expanded', 'true');
      popMenuButton(btn);
    });
  } else {
    const delay   = 0;
    const trans   = 200;
    const totalMs = items.length * delay + trans;
    closeNav(nav, items, delay, trans, totalMs).then(() => {
      btn.setAttribute('aria-expanded', 'false');
      popMenuButton(btn);
    });
  }
}

// ——————————————————
// Init Nav
// ——————————————————
export function initNav() {
  const btn = document.getElementById('menu-toggle');
  const nav = document.getElementById('nav-links');
  if (!btn || !nav) return;

  // Reset default state
  nav.classList.remove('show', 'closing');
  nav.style.overflow = 'hidden';
  nav.style.height = '0';
  btn.setAttribute('aria-expanded', 'false');

  nav.querySelectorAll('li').forEach(li => li.style.display = 'none');

  // Bind click / keyboard toggle
  btn.addEventListener('click', () => sinkThenPop(btn));
  btn.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      sinkThenPop(btn);
    }
  });

  // Collapse nav when any link is clicked
  nav.querySelectorAll('a').forEach(a =>
    a.addEventListener('click', () => {
      nav.classList.remove('show');
      btn.setAttribute('aria-expanded', 'false');
    })
  );
}