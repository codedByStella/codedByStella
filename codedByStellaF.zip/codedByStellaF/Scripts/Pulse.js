// ——————————————————
// Pulse.js — Unified Shimmer + Spin Sync System
// ——————————————————
let _pulseTimer = null;
const BEAT_INTERVAL = 1250; // ms
const SYNC_ANGLE = 'rotateY(90deg)';

function injectPulseStyles() {
  if (document.getElementById('pulse-style')) return;

  const style = document.createElement('style');
  style.id = 'pulse-style';
  style.textContent = `
    @keyframes nav-shimmer-slide {
      0%   { left: -100%; opacity: 0.5; }
      10%, 90% { opacity: 1; }
      100% { left: 100%; opacity: 0.5; }
    }

    .nav-shimmer-bar {
      position: relative;
      overflow: hidden;
      z-index: 1;
    }

    .nav-shimmer-bar::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: rgba(255,105,180,0.2);
      opacity: 0.5;
      z-index: 2;
      pointer-events: none;
    }

    .nav-shimmer-active::before {
      animation: nav-shimmer-slide 0.8s ease-in-out;
    }

    .nav-shimmer-hidden::before {
      opacity: 0 !important;
      animation: none !important;
    }

    @keyframes coin-spin {
      from { transform: rotateY(0); }
      to   { transform: rotateY(360deg); }
    }

    .nav-icon.coin-spin {
      animation: coin-spin 2.5s linear infinite;
      transform-style: preserve-3d;
    }
  `;
  document.head.appendChild(style);
}

function pulseShimmer() {
  const nav = document.querySelector('.nav-links');
  if (!nav || nav.classList.contains('nav-shimmer-hidden')) return;
  nav.classList.add('nav-shimmer-active');
  nav.addEventListener('animationend', () => nav.classList.remove('nav-shimmer-active'), { once: true });
}

function setInitialSpinAngle() {
  const icons = document.querySelectorAll('.nav-icon');
  icons.forEach(icon => {
    icon.style.transform = SYNC_ANGLE;
  });
}

export function startPulse() {
  injectPulseStyles();

  const nav = document.querySelector('.nav-links');
  if (!nav) return;

  // Cancel any previous loop
  if (_pulseTimer) cancelAnimationFrame(_pulseTimer);

  if (!nav.classList.contains('nav-shimmer-bar')) {
    nav.classList.add('nav-shimmer-bar');
  }

  // Set all icons to correct angle before spin begins
  setInitialSpinAngle();

  // Add spin class to all icons
  document.querySelectorAll('.nav-icon').forEach(icon => {
    icon.classList.add('coin-spin');
  });

  // Start shimmer pulse loop
  let start = performance.now();
  function loop(now) {
    const elapsed = now - start;
    if (elapsed % BEAT_INTERVAL < 17) pulseShimmer();
    _pulseTimer = requestAnimationFrame(loop);
  }

  _pulseTimer = requestAnimationFrame(loop);
}

export function stopPulse() {
  if (_pulseTimer) cancelAnimationFrame(_pulseTimer);
  _pulseTimer = null;
}