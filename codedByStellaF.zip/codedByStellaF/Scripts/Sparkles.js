const sparkleMinRadius = 4;
const sparkleMaxRadius = 10;

function injectSparkleStyles() {
  if (document.getElementById('sparkle-style')) return;
  const style = document.createElement('style');
  style.id = 'sparkle-style';
  style.textContent = `
    .sparkle-wrap, .sparkle-pair {
      width:32px; height:32px; position:relative; display:flex;
      align-items:center; justify-content:center; pointer-events:none;
    }
    .sparkle-icon {
      width:28px; height:28px; filter:drop-shadow(0 0 4px white);
      z-index:2; display:flex; align-items:center; justify-content:center;
    }
    .dust-cluster {
      position:absolute; top:50%; left:50%;
      width:100%; height:100%;
      transform: translate(-58%, -65%); /* ← SHIFT LEFT & UP */
      z-index:1; pointer-events:none;
    }
    .dust {
      position:absolute; width:6px; height:6px; border-radius:50%;
      opacity:0;
    }

    @keyframes sparkleFloat {
      0%   { transform: translate(0, 0) scale(1); opacity: 1; }
      25%  { transform: translate(-1.5px, 25%) scale(0.9); }
      50%  { transform: translate(1.5px, 50%) scale(0.6); }
      75%  { transform: translate(-1px, 75%) scale(0.3); }
      100% { transform: translate(1px, 150%) scale(0); opacity: 0; }
    }
  `;
  document.head.appendChild(style);
}

function animateSparkle(dot) {
  const colors = ['#ffd6ff', '#caffbf', '#b5e4ff', '#ffe8a3', '#ffb3c1'];

  function loop() {
    const angle = Math.random() * 2 * Math.PI;
    const r = sparkleMinRadius + Math.random() * (sparkleMaxRadius - sparkleMinRadius);
    const x = r * Math.cos(angle);
    const y = r * Math.sin(angle);
    const c = colors[Math.floor(Math.random() * colors.length)];
    const duration = 2200 + Math.random() * 1000;
    const delay = Math.random() * 1000;

    dot.style.animation = 'none';
    void dot.offsetHeight;

    dot.style.left = `calc(50% + ${x}px)`;
    dot.style.top  = `calc(50% + ${y}px)`;
    dot.style.backgroundColor = c;
    dot.style.filter = `drop-shadow(0 0 4px ${c})`;

    dot.style.animation = `sparkleFloat ${duration}ms ease-out forwards`;

    setTimeout(loop, duration + delay);
  }

  setTimeout(loop, Math.random() * 500);
}

export function initSparkles() {
  injectSparkleStyles();
  document.querySelectorAll('.dust-cluster').forEach(cluster => {
    cluster.innerHTML = '';
    for (let i = 0; i < 12; i++) {
      const dot = document.createElement('span');
      dot.className = 'dust';
      cluster.appendChild(dot);
      animateSparkle(dot);
    }
  });
}

export function injectMenuSparkles() {
  injectSparkleStyles();
  const btn = document.getElementById('menu-toggle');
  if (!btn) return;
  const txt = btn.querySelector('.menu-text');
  const makePair = () => {
    const wrap = document.createElement('span');
    wrap.className = 'sparkle-wrap';
    const pair = document.createElement('div');
    pair.className = 'sparkle-pair';
    const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.classList.add('sparkle-icon');
    svg.setAttribute('viewBox','0 0 24 24');
    svg.innerHTML = `<path d="M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z" fill="#fff"/>`;
    const dust = document.createElement('div');
    dust.className = 'dust-cluster';
    pair.append(svg, dust);
    wrap.append(pair);
    return wrap;
  };
  const left = makePair(), right = makePair();
  const flex = document.createElement('div');
  flex.style.display = 'inline-flex';
  flex.style.alignItems = 'center';
  flex.style.justifyContent = 'center';
  flex.style.gap = '0.6rem';
  flex.append(left, txt.cloneNode(true), right);
  btn.innerHTML = '';
  btn.append(flex);
  initSparkles();
}