// Scripts/Element-Loader.js

import { includeHTML } from './Loader.js';
import { startPulse } from './Pulse.js';
import { injectLogoTextStyles, initLogoText } from './Elements/Logo-Text.js';
import { injectTaglineTextStyles, initTaglineText } from './Elements/Tagline-Text.js';

document.addEventListener('DOMContentLoaded', () => {
  console.log('✅ DOM fully loaded');

  includeHTML('navbar-include', 'Universal.html')
    .then(() => {
      console.log('✅ Header injected');
      injectLogoTextStyles();
      initLogoText();

      injectTaglineTextStyles(); 
      initTaglineText();         

      startPulse();
    })
    .catch(err => console.error('[includeHTML] Error:', err));
});